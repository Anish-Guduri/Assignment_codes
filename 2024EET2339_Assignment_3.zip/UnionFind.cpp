class UnionFind {
private:
    int *parent, *rank;  // Arrays to store the parent and rank of each element

public:
// Initializes parent and rank arrays for Union-Find structure.
    UnionFind(int n) {
        parent = new int[n];  
        rank = new int[n];   
        for (int i = 0; i < n; i++) {
            parent[i] = i;   
            rank[i] = 0;     
        }
    }
// Cleans up dynamically allocated memory for parent and rank arrays.
    ~UnionFind() {
        delete[] parent;     
        delete[] rank;       
    }
// Finds the root of the set containing u.
    int find(int u) {
        if (u != parent[u]) parent[u] = find(parent[u]);
        return parent[u];
    }
// Unites two sets containing elements u and v using union by rank to optimize the merging process.
    void unionSets(int u, int v) {
        int rootU = find(u);  
        int rootV = find(v); 
        if (rootU != rootV) {
            if (rank[rootU] < rank[rootV]) {
                parent[rootU] = rootV;  
            } else if (rank[rootU] > rank[rootV]) {
                parent[rootV] = rootU; 
            } else {
                parent[rootV] = rootU;   
                rank[rootU]++;
            }
        }
    }
};

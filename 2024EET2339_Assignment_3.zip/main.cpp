#include "Graph.h"
#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>
#include <chrono>

using namespace std;

extern Graph primMST(const Graph& graph);
extern Graph kruskalMST(const Graph& graph);

// SimpleQueue class for managing integer queue operations
class SimpleQueue {
    vector<int> data;
    int frontIndex = 0;

public:
    void push(int value) {
        data.push_back(value);  // Add value to the queue
    }

    void pop() {
        if (frontIndex < data.size()) {
            frontIndex++;  
        }
    }

    int front() {
        return data[frontIndex];  
    }

    bool empty() {
        return frontIndex >= data.size();  
    }
};

// Function to check if all vertices are connected in the graph
bool isConnected(const Graph& graph, int numVertices) {
    if (numVertices == 0) return false;  

    vector<bool> visited(numVertices, false);
    SimpleQueue q;                              
    q.push(0);                                  
    visited[0] = true;                          
    int count = 1;                              

    while (!q.empty()) {                        
        int v = q.front();                      
        q.pop();                                

        for (int u = 0; u < numVertices; ++u) {  
            if (graph.getWeight(v, u) != -1 && !visited[u]) {  
                visited[u] = true;              
                q.push(u);                      
                count++;                        
            }
        }
    }

    return count == numVertices;                
}

int main() {
    ifstream inputFile("cost_matrix.txt");
    if (!inputFile) {
        cerr << "Error: Unable to open cost_matrix.txt" << endl;
        return 1;  
    }

    vector<vector<int>> matrix;                // 2D vector to store the cost matrix
    string line;
    while (getline(inputFile, line)) {         // Read each line from the file
        vector<int> row;
        int weight;
        istringstream iss(line);
        while (iss >> weight) {                 // Reading weights from the line
            row.push_back(weight);
        }
        matrix.push_back(row);                  
    }
    inputFile.close();                          

    int numVertices = matrix.size();           

    if (numVertices == 0) {
        cout << "Invalid input: Empty graph." << endl;
        return 0;  
    }

    // Validating the matrix for non-zero values on the diagonal and negative weights
    for (int i = 0; i < numVertices; i++) {
        if (matrix[i][i] != 0) {               
            cout << "Invalid input: Non-zero value on the diagonal at vertex " << i << "." << endl;
            return 0;  
        }
        for (int j = 0; j < numVertices; j++) {
            if (matrix[i][j] != matrix[j][i]) {  
                cout << "Invalid input: Directed edge detected between vertices " << i << " and " << j << "." << endl;
                return 0;  
            }
            if (matrix[i][j] < -1) {              
                cout << "Invalid input: Negative weight found at edge (" << i << ", " << j << ")." << endl;
                return 0;  
            }
        }
    }

    Graph graph(numVertices);                   

    // Adding edges to the graph based on the cost matrix
    for (int i = 0; i < numVertices; i++) {
        for (int j = 0; j < numVertices; j++) {
            int weight = matrix[i][j];
            if (weight != -1 && i != j) {  // Add edge if valid and not a self-loop
                graph.addEdge(i, j, weight);
            }
        }
    }

    // Checking if the graph is connected
    if (!isConnected(graph, numVertices)) {
        cout << "Invalid input: Graph is disconnected." << endl;
        return 0;  
    }

    cout << "Graph loaded with " << numVertices << " vertices." << endl;

    // Finding MST using Prim's algorithm, and calculating time for Prim's algorithm implementation
    auto start = chrono::high_resolution_clock::now();
    Graph mstPrim = primMST(graph);                // Find MST using Prim's algorithm
    auto end = chrono::high_resolution_clock::now();
    auto primTime = chrono::duration_cast<chrono::nanoseconds>(end - start).count();
    cout << "\nPrim's algorithm MST (total cost: " << mstPrim.getTotalCost() << "; runtime: " << primTime << " nanoseconds)" << endl;
    mstPrim.displayEdges();                       

    // Finding MST using Kruskal's algorithm, and calculating time for Kruskal's algorithm implementation
    start = chrono::high_resolution_clock::now();
    Graph mstKruskal = kruskalMST(graph);         
    end = chrono::high_resolution_clock::now();
    auto kruskalTime = chrono::duration_cast<chrono::nanoseconds>(end - start).count();
    cout << "\nKruskal's algorithm MST (total cost: " << mstKruskal.getTotalCost() << "; runtime: " << kruskalTime << " nanoseconds)" << endl;
    mstKruskal.displayEdges();                    

    return 0;  
}

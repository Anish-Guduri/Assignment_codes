
# MST Assignment 3

This project implements Minimum Spanning Tree (MST) algorithms using both Prim's and Kruskal's methods.

## Files Overview

- **main.cpp**: Entry point for the program. Handles initialization and executes MST algorithms based on input.
- **Prim.cpp**: Implements Prim's algorithm to find the MST of a graph.
- **Kruskal.cpp**: Implements Kruskal's algorithm to find the MST of a graph.
- **PriorityQueue.cpp**: Provides a priority queue for selecting edges efficiently in MST algorithms.
- **UnionFind.cpp**: Implements the Union-Find data structure, used in Kruskal's algorithm to detect cycles.
- **Graph.cpp and Graph.h**: Define the graph structure and helper methods for manipulating graphs.
- **cost_matrix.txt**: Contains an edge cost matrix or adjacency representation for the graph.

## How to Run the Code

### Requirements

- **Compiler**: A C++ compiler such as g++.

### Compilation

To compile the code, use the following command in the terminal:

```bash
g++ -o mst main.cpp Prim.cpp Kruskal.cpp PriorityQueue.cpp UnionFind.cpp Graph.cpp
```

### Execution

To run the compiled executable:

```bash
./mst
```

The program reads from `cost_matrix.txt` for graph data. Ensure that this file is in the same directory as the executable.

## Code Structure

1. **Main Function (`main.cpp`)**: Initializes the graph and calls either Prim's or Kruskal's algorithm based on user input.
2. **Prim's Algorithm (`Prim.cpp`)**: Uses a priority queue to select edges, growing the MST starting from a specific node.
3. **Kruskal's Algorithm (`Kruskal.cpp`)**: Uses the Union-Find structure to select edges by increasing order of weight, ensuring no cycles.
4. **Data Structures**:
   - **Priority Queue (`PriorityQueue.cpp`)**: Facilitates efficient edge selection in Prim's algorithm.
   - **Union-Find (`UnionFind.cpp`)**: Maintains a disjoint-set data structure, essential for cycle detection in Kruskal's algorithm.
   - **Graph (`Graph.cpp`, `Graph.h`)**: Provides an adjacency list-based graph representation and helper functions.

## Example `cost_matrix.txt`

The `cost_matrix.txt` file should contain a square matrix of edge weights, where each row represents edges connected to a node. Here is an example format:

```
0 2 3 0
2 0 0 1
3 0 0 4
0 1 4 0
```

In this example, each non-zero entry represents an edge weight between nodes.

## Notes

- Ensure all `.cpp` and `.h` files are in the same directory as the main program file before compiling.
- The executable, `mst.exe`, is precompiled and included but may not work on all systems. It is recommended to recompile using the steps provided.


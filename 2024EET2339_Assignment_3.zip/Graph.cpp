#include "Graph.h"
#include <iostream>

using namespace std;

Graph::Graph(int vertices) : numVertices(vertices) {
    // Creating an adjacency matrix for the graph
    adjMatrix = new int*[numVertices];
    for (int i = 0; i < numVertices; i++) {
        adjMatrix[i] = new int[numVertices];
        for (int j = 0; j < numVertices; j++) {
            // Initializing diagonal to 0 and others to -1
            adjMatrix[i][j] = (i == j) ? 0 : -1;  
        }
    }
}

Graph::~Graph() {
    // Deleting the adjacency matrix
    for (int i = 0; i < numVertices; i++) delete[] adjMatrix[i];
    delete[] adjMatrix;
}

void Graph::addEdge(int src, int dest, int weight) {
    // Adding an edge from source to destination with a given weight
    adjMatrix[src][dest] = weight;
    adjMatrix[dest][src] = weight;  // Because it's undirected
}

int Graph::getWeight(int src, int dest) const {
    // finds the weight of the edge from src to dest
    return adjMatrix[src][dest];
}

int Graph::getVertices() const {
    // Returns the number of vertices in the graph
    return numVertices;
}

void Graph::displayEdges() const {
    // Printing all the edges in the graph
    for (int i = 0; i < numVertices; i++) {
        for (int j = i + 1; j < numVertices; j++) {
            // Checking if there is an edge
            if (adjMatrix[i][j] != -1 && adjMatrix[i][j] != 0) {
                cout << "(" << i + 1 << "," << j + 1 << ")" << endl;
            }
        }
    }
}

int Graph::getTotalCost() const {
    // Calculating the total cost of all edges
    int totalCost = 0;
    for (int i = 0; i < numVertices; i++) {
        for (int j = i + 1; j < numVertices; j++) {
            // Adding the weight if there's an edge
            if (adjMatrix[i][j] != -1 && adjMatrix[i][j] != 0) {
                totalCost += adjMatrix[i][j];
            }
        }
    }
    return totalCost;
}

bool Graph::hasEdge(int v, int u) const {
    // Will Check if there's an edge between v and u
    return adjMatrix[v][u] != -1;
}

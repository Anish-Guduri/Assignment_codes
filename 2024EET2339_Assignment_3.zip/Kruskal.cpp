#include "Graph.h"
#include "UnionFind.cpp"
#include <vector>

using namespace std;

Graph kruskalMST(const Graph& graph) {
    int vertices = graph.getVertices();  
    Graph mst(vertices);                  
    UnionFind uf(vertices);               // Create a Union-Find structure for cycle detection

    struct Edge { int src, dest, weight; }; // Define a structure for graph edges
    vector<Edge> edges;                   

    // Loop to collect all edges from the graph, avoiding duplicates
    for (int i = 0; i < vertices; i++) {
        for (int j = i + 1; j < vertices; j++) {  
            int weight = graph.getWeight(i, j);  
            if (weight != -1) {                     
                edges.push_back({ i, j, weight });  
            }
        }
    }

    // Sorting of edges using bubble sort
    for (size_t i = 0; i < edges.size(); i++) {
        for (size_t j = 0; j < edges.size() - 1 - i; j++) {
            if (edges[j].weight > edges[j + 1].weight) {
                swap(edges[j], edges[j + 1]);
            }
        }
    }

    // Adding sorted edges to MST using union-find to prevent cycles
    for (const auto& edge : edges) {                       
        if (uf.find(edge.src) != uf.find(edge.dest)) {   
            uf.unionSets(edge.src, edge.dest);            
            mst.addEdge(edge.src, edge.dest, edge.weight);
        }
    }

    return mst;  
}

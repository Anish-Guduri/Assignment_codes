#ifndef GRAPH_H
#define GRAPH_H

#include <vector>

class Graph {
private:
    int **adjMatrix;        // Adjacency matrix for storing edge weights
    int numVertices;        // Number of vertices in the graph

public:
    Graph(int vertices);               // Constructor
    ~Graph();                          // Destructor
    void addEdge(int src, int dest, int weight);   // Adds an edge with weight
    int getWeight(int src, int dest) const;        // Retrieves edge weight
    int getVertices() const;                       // Returns number of vertices
    void displayEdges() const;                     // Displays all edges
    int getTotalCost() const;                      // Calculates total edge cost
    bool hasEdge(int v, int u) const;              // Checks if edge exists
};

#endif


#include "Graph.h"
#include "PriorityQueue.cpp"

// Function to find the Minimum Spanning Tree (MST) using Prim's algorithm
Graph primMST(const Graph& graph) {
    int vertices = graph.getVertices();          
    Graph mst(vertices);                          
    int *parent = new int[vertices];             // To store parent vertices
    int *key = new int[vertices];                // To store minimum weights
    bool *inMST = new bool[vertices];            // To track vertices in MST

    // Initialize key values and MST inclusion
    for (int i = 0; i < vertices; i++) {
        key[i] = INT_MAX;                        
        inMST[i] = false;                        
    }

    key[0] = 0;                                  
    parent[0] = -1;                             

    PriorityQueue pq(vertices);                  // Create a priority queue
    pq.decreaseKey(0, key[0]);                  

    while (!pq.isEmpty()) {                      
        int u = pq.deleteMin();                  
        inMST[u] = true;                         

        if (parent[u] != -1) {                   // If not the first vertex
            mst.addEdge(parent[u], u, key[u]);  
        }

        // Update keys for neighboring vertices
        for (int v = 0; v < vertices; v++) {
            int weight = graph.getWeight(u, v); 
            // Check for a valid edge and if it can improve the key value
            if (weight != -1 && !inMST[v] && weight < key[v]) {
                key[v] = weight;                 
                parent[v] = u;                   
                pq.decreaseKey(v, key[v]);
            }
        }
    }

    // Clean up memory
    delete[] parent;
    delete[] key;
    delete[] inMST;
    return mst;                                  // Return the resulting MST
}

#include <limits.h>

class PriorityQueue {
private:
    int *keys;
    int *positions;
    int *vertexMap;
    int capacity;
    int size;

// Swaps the values of two integers.
    void swap(int &a, int &b) {
        int temp = a;
        a = b;
        b = temp;
    }

// Maintains the min-heap property by ensuring the subtree rooted at index i is a min-heap.

    void minHeapify(int i) {
        int smallest = i;
        int left = 2 * i + 1;
        int right = 2 * i + 2;

        if (left < size && keys[left] < keys[smallest]) smallest = left;
        if (right < size && keys[right] < keys[smallest]) smallest = right;

        if (smallest != i) {
            swap(keys[i], keys[smallest]);
            swap(positions[i], positions[smallest]);
            swap(vertexMap[positions[i]], vertexMap[positions[smallest]]);
            minHeapify(smallest);
        }
    }

public:
// Initializes the priority queue with the given capacity and sets initial key values to infinity.

    PriorityQueue(int capacity) : capacity(capacity), size(capacity) {
        keys = new int[capacity];
        positions = new int[capacity];
        vertexMap = new int[capacity];
        for (int i = 0; i < capacity; i++) {
            keys[i] = INT_MAX;
            positions[i] = i;
            vertexMap[i] = i;
        }
    }

// Cleans up dynamically allocated memory for keys, positions, and vertexMap arrays.

    ~PriorityQueue() {
        delete[] keys;
        delete[] positions;
        delete[] vertexMap;
    }
// Decreases the key value of vertex v to newKey and maintains the min-heap property.
    void decreaseKey(int v, int newKey) {
        int i = vertexMap[v];
        keys[i] = newKey;

        while (i != 0 && keys[i] < keys[(i - 1) / 2]) {
            swap(keys[i], keys[(i - 1) / 2]);
            swap(positions[i], positions[(i - 1) / 2]);
            swap(vertexMap[positions[i]], vertexMap[positions[(i - 1) / 2]]);
            i = (i - 1) / 2;
        }
    }

// Removes and returns the vertex with the minimum key value from the priority queue.
    int deleteMin() {
        if (size <= 0) return -1;
        int root = positions[0];
        keys[0] = keys[size - 1];
        positions[0] = positions[size - 1];
        vertexMap[positions[0]] = 0;
        size--;
        minHeapify(0);

        return root;
    }

// Checks if the priority queue is empty.
    bool isEmpty() {
        return size == 0;
    }
};
